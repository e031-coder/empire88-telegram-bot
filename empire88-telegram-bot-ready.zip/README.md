# Empire88 Telegram Bot

Cloudflare Worker Telegram promotional bot.

## Required Cloudflare secrets

- `BOT_TOKEN`
- `WEBHOOK_SECRET`

## After deployment

Open:

`https://empire88-telegram-bot.e031.workers.dev/setup`

Then send `/start` to the Telegram bot.
