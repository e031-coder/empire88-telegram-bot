const WORKER_URL = "https://empire88-telegram-bot.e031.workers.dev";

const REGISTER_URL = "https://sho-rt.org/?ref=5GENIL";
const DOWNLOAD_APP_URL = "https://sho-rt.org/?ref=5GENIL";
const CHANNEL_URL = "https://t.me/empire88channel";
const SUPPORT_URL = "https://t.me/Aurelia_1317";
const WELCOME_IMAGE_URL = "https://i.imgur.com/X5v4cI5.png";

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (request.method === "GET" && url.pathname === "/") {
      return new Response("Empire88 Telegram Bot is running.");
    }

    if (request.method === "GET" && url.pathname === "/setup") {
      if (!env.BOT_TOKEN || !env.WEBHOOK_SECRET) {
        return Response.json(
          { ok: false, error: "BOT_TOKEN or WEBHOOK_SECRET is missing." },
          { status: 500 }
        );
      }

      const result = await telegramApi(env.BOT_TOKEN, "setWebhook", {
        url: `${WORKER_URL}/webhook`,
        secret_token: env.WEBHOOK_SECRET,
        allowed_updates: ["message", "callback_query"],
        drop_pending_updates: true,
      });

      return Response.json(result);
    }

    if (request.method === "POST" && url.pathname === "/webhook") {
      const telegramSecret = request.headers.get(
        "X-Telegram-Bot-Api-Secret-Token"
      );

      if (!env.WEBHOOK_SECRET || telegramSecret !== env.WEBHOOK_SECRET) {
        return new Response("Unauthorized", { status: 401 });
      }

      try {
        const update = await request.json();
        await handleUpdate(update, env);
      } catch (error) {
        console.error("Webhook error:", error);
      }

      return new Response("OK");
    }

    return new Response("Not found", { status: 404 });
  },
};

async function handleUpdate(update, env) {
  if (update.message) {
    const chatId = update.message.chat.id;
    const text = update.message.text || "";

    if (text.startsWith("/start")) {
      await sendWelcome(chatId, env);
      return;
    }

    await sendMessage(chatId, "请选择下方菜单 👇", mainMenu(), env);
    return;
  }

  if (update.callback_query) {
    const callback = update.callback_query;
    const chatId = callback.message.chat.id;

    await telegramApi(env.BOT_TOKEN, "answerCallbackQuery", {
      callback_query_id: callback.id,
    });

    if (callback.data === "promotions") {
      await sendMessage(
        chatId,
        "🎁 <b>Empire88 Promotions</b>\n\n查看最新会员优惠及特别活动。\n\n点击下方按钮立即开始。",
        {
          inline_keyboard: [
            [{ text: "🔥 Claim Bonus", url: REGISTER_URL }],
            [{ text: "⬅️ Back to Menu", callback_data: "main_menu" }],
          ],
        },
        env
      );
      return;
    }

    if (callback.data === "main_menu") {
      await sendMessage(chatId, "请选择你需要的服务 👇", mainMenu(), env);
    }
  }
}

async function sendWelcome(chatId, env) {
  const caption =
    "👋 <b>Welcome to Empire88</b>\n\n" +
    "One App. Endless Entertainment.\n\n" +
    "请选择你需要的服务 👇";

  const result = await telegramApi(env.BOT_TOKEN, "sendPhoto", {
    chat_id: chatId,
    photo: WELCOME_IMAGE_URL,
    caption,
    parse_mode: "HTML",
    reply_markup: mainMenu(),
  });

  // 如果图片发送失败，仍然发送文字菜单
  if (!result.ok) {
    await sendMessage(chatId, caption, mainMenu(), env);
  }
}

function mainMenu() {
  return {
    inline_keyboard: [
      [
        { text: "🎁 Promotions", callback_data: "promotions" },
        { text: "🌐 Register", url: REGISTER_URL },
      ],
      [
        { text: "📥 Download APP", url: DOWNLOAD_APP_URL },
        { text: "📢 Official Channel", url: CHANNEL_URL },
      ],
      [{ text: "💬 Customer Support", url: SUPPORT_URL }],
    ],
  };
}

async function sendMessage(chatId, text, replyMarkup, env) {
  return telegramApi(env.BOT_TOKEN, "sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    reply_markup: replyMarkup,
  });
}

async function telegramApi(token, method, body) {
  const response = await fetch(
    `https://api.telegram.org/bot${token}/${method}`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    }
  );

  const result = await response.json();

  if (!result.ok) {
    console.error(`Telegram ${method} error:`, result);
  }

  return result;
}
